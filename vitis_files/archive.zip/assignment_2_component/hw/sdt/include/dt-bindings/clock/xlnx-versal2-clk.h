/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (C) 2022, Xilinx Inc.
 * Copyright (C) 2022 - 2026, Advanced Micro Devices, Inc.
 */

#ifndef _DT_BINDINGS_CLK_VERSAL2_H
#define _DT_BINDINGS_CLK_VERSAL2_H

#include "xlnx-versal-net-clk.h"

#define CAN2_REF_2X	0xC1
#define CAN3_REF_2X	0xC6
#define I3C2_REF	0xBD
#define I3C3_REF	0xBC
#define I3C4_REF	0xBB
#define I3C5_REF	0xC7
#define I3C6_REF	0xC4
#define I3C7_REF	0xC3
#define TTC4		0xCC
#define TTC5		0xCD
#define TTC6		0xCE
#define TTC7		0xCF
#define UFS_REF		0xC8
#define MMI_DRD_REF_CLK	0xD0
#define MMIPLL		0xD7
#define GPU_PLL		0xD9
#define DC_PIXEL	0xDA
#define GPU_REF		0xDB
#define MMI_AUX0_REF	0xDC
#define PS_AXI_DMA	0xDD
#define MMI_AUX1_REF	0xDF
#define MMI_GEM_HCLK	0xE0
#define DC_REF		0xE2
#define DC_27M		0xE3
#define EIO_UART0_REF	0xE6
#define EIO_UART1_REF	0xE7
#define EIO_UART2_REF	0xE8
#define EIO_SPI0_REF	0xE9
#define EIO_SPI1_REF	0xEA
#define EIO_SPI2_REF	0xEB
#define EIO_SPI3_REF	0xEC

#endif
